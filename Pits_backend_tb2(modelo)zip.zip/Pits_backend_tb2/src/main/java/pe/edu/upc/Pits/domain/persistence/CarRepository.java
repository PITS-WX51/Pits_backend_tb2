package pe.edu.upc.Pits.domain.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.Pits.domain.model.entity.Brand;
import pe.edu.upc.Pits.domain.model.entity.Car;
import pe.edu.upc.Pits.domain.model.entity.User;

import java.util.List;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {
	Car findByTuition(String tuition);
	@Query("SELECT u.plants FROM User u WHERE u.id = ?1")
	Brand getBrandById(Integer id);
	
	@Query("SELECT u.events FROM User u WHERE u.id = ?1")
	List<User> getUserByUserId(Integer id);
}
