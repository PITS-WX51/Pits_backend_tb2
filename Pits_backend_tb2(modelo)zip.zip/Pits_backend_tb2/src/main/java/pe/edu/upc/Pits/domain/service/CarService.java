package pe.edu.upc.Pits.domain.service;

import pe.edu.upc.Pits.domain.model.entity.Brand;
import pe.edu.upc.Pits.domain.model.entity.Car;
import pe.edu.upc.Pits.domain.model.entity.User;

import java.util.List;

public interface CarService extends CrudService<Car>{
	Car findByTuition(String tuition) throws Exception;
	Brand getBrandById(Integer id) throws Exception;
	List<User> getUserByUserId(Integer id) throws Exception;
}
