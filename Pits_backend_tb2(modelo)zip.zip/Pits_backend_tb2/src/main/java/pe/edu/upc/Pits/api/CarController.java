package pe.edu.upc.Pits.api;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.Pits.domain.model.entity.Car;
import pe.edu.upc.Pits.domain.service.CarService;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("cars")
@Api(tags = "Cars", value = "Web Service RESTful - Cars")
public class CarController {
	
	private final CarService carService;
	
	public CarController(CarService carService)
	{
		this.carService = carService;
	}
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "List Cars", notes = "Method for list all Cars")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Cars found"),
		@ApiResponse(code = 404, message = "Cars not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<List<Car>> findAllCars(){
		try{
			List<Car> cars = carService.getAll();
			return new ResponseEntity<>(cars, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Find Cars by Id", notes = "Method for list one Cars by Id")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Car found"),
		@ApiResponse(code = 404, message = "Car not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Car> findCarsById(@PathVariable("id") Integer id){
		try{
			Optional<Car> car = carService.getById(id);
			if(!car.isPresent())
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			return new ResponseEntity<>(car.get(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/searchByTuition/{Tuition}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Found Car by Tuition", notes = "Method for list one Car by Tuition")
	public ResponseEntity<Car> findCarsByTuition(@PathVariable("Tuition") String tuition){
		try{
			Car car = carService.findByTuition(tuition);
			if(car != null)
				return  new ResponseEntity<>(car, HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Insert Car", notes = "Method for insert new Car")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Car created"),
		@ApiResponse(code = 404, message = "Car not created"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Car> insertCar(@Valid @RequestBody Car car){
		try{
			Car carNew = carService.save(car);
			return ResponseEntity.status(HttpStatus.CREATED).body(carNew);
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update data for Car", notes = "Method for update data for Car")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Data for Car updated"),
		@ApiResponse(code = 404, message = "Car not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Car> updateCar(@PathVariable("id") Integer id, @Valid @RequestBody Car car){
		try{
			Optional<Car> carOld = carService.getById(id);
			if(!carOld.isPresent())
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else{
				car.setId(id);
				carService.save(car);
				return new ResponseEntity<>(car, HttpStatus.OK);
			}
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete Car by Id", notes = "Method for delete Car")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Car deleted"),
		@ApiResponse(code = 404, message = "Car not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Car> deleteCar(@PathVariable("id") Integer id){
		try{
			Optional<Car> bookingDelete = carService.getById(id);
			if(bookingDelete.isPresent()){
				carService.delete(id);
				return new ResponseEntity<>(HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
