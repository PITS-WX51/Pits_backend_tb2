package pe.edu.upc.Pits.service.impl;


import org.springframework.transaction.annotation.Transactional;
import pe.edu.upc.Pits.domain.model.entity.Brand;
import pe.edu.upc.Pits.domain.persistence.BrandRepository;
import pe.edu.upc.Pits.domain.service.BrandService;

import java.util.List;
import java.util.Optional;

public class BrandServiceImpl implements BrandService {
	private final BrandRepository brandRepository;
	public BrandServiceImpl(BrandRepository brandRepository)
	{this.brandRepository=brandRepository;}
	
	@Override
	@Transactional
	public Brand save(Brand brand) throws Exception {
		return brandRepository.save(brand);
	}
	@Override
	@Transactional
	public void delete(Integer id) throws Exception {
		brandRepository.deleteById(id);
	}
	
	@Override
	public List<Brand> getAll() throws Exception {
		return brandRepository.findAll();
	}
	
	@Override
	public Optional<Brand> getById(Integer id) throws Exception {
		return brandRepository.findById(id);
	}
	
	@Override
	public Brand findByName(String name) throws Exception {
		return brandRepository.findByName(name);
	}
}
