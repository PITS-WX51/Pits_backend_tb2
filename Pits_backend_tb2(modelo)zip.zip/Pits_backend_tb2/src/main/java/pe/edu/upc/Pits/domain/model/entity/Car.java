package pe.edu.upc.Pits.domain.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "cars")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Car implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@NotNull
	@Size(max = 6, min = 6)
	@NotBlank
	@Column(name = "tuition", length = 50, nullable = false)
	private String tuition;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	//@JoinColumn(name = "brands")
	private Brand brand;
	
	@JsonIgnore
	@ManyToMany(mappedBy = "cars", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	//@JoinColumn(name = "users")
	private List<User> users;
}
