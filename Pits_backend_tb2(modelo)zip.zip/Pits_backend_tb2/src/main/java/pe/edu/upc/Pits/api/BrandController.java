package pe.edu.upc.Pits.api;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.Pits.domain.model.entity.Brand;
import pe.edu.upc.Pits.domain.service.BrandService;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("brands")
@Api(tags = "Brand", value = "Web Service RESTful - Brands")
public class BrandController {
	private final BrandService brandService;
	
	public BrandController(BrandService brandService)
	{
		this.brandService = brandService;
	}
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "List Brands", notes = "Method for list all brands")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Brands found"),
		@ApiResponse(code = 404, message = "Brands not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<List<Brand>> findAllBrands(){
		try{
			List<Brand> brands = brandService.getAll();
			return new ResponseEntity<>(brands, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Find brands by Id", notes = "Method for list one brands by Id")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Brand found"),
		@ApiResponse(code = 404, message = "Brand not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Brand> findBrandsById(@PathVariable("id") Integer id){
		try{
			Optional<Brand> brand = brandService.getById(id);
			if(!brand.isPresent())
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			return new ResponseEntity<>(brand.get(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/searchByName/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Found Brand by Name", notes = "Method for list one Brand by Id")
	public ResponseEntity<Brand> findBrandsByName(@PathVariable("name") String name){
		try{
			Brand brand = brandService.findByName(name);
			if(brand != null)
				return  new ResponseEntity<>(brand, HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Insert Brand", notes = "Method for insert new Brand")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Brand created"),
		@ApiResponse(code = 404, message = "Brand not created"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Brand> insertBrand(@Valid @RequestBody Brand brand){
		try{
			Brand brandNew = brandService.save(brand);
			return ResponseEntity.status(HttpStatus.CREATED).body(brandNew);
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update data for Brand", notes = "Method for update data for Brand")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Data for Brand updated"),
		@ApiResponse(code = 404, message = "Brand not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Brand> updateBrand(@PathVariable("id") Integer id, @Valid @RequestBody Brand brand){
		try{
			Optional<Brand> brandOld = brandService.getById(id);
			if(!brandOld.isPresent())
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else{
				brand.setId(id);
				brandService.save(brand);
				return new ResponseEntity<>(brand, HttpStatus.OK);
			}
		}catch (Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete Brand by Id", notes = "Method for delete Brand")
	@ApiResponses({
		@ApiResponse(code = 201, message = "Brand deleted"),
		@ApiResponse(code = 404, message = "Brand not found"),
		@ApiResponse(code = 501, message = "Internal Server Error")
	})
	public ResponseEntity<Brand> deleteBrand(@PathVariable("id") Integer id){
		try{
			Optional<Brand> bookingDelete = brandService.getById(id);
			if(bookingDelete.isPresent()){
				brandService.delete(id);
				return new ResponseEntity<>(HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
