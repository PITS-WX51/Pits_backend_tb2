package pe.edu.upc.Pits.shared;

public class Constant {
	public static final String USER_ENTITY = "User";
	public static final String MECHANIC_ENTITY = "Mechanic";
}
