package pe.edu.upc.Pits.service.impl;


import org.springframework.transaction.annotation.Transactional;
import pe.edu.upc.Pits.domain.model.entity.Car;
import pe.edu.upc.Pits.domain.persistence.CarRepository;
import pe.edu.upc.Pits.domain.service.CarService;

import java.util.List;
import java.util.Optional;

public class CarServiceImpl implements CarService{
	private final CarRepository carRepository;
	public CarServiceImpl(CarRepository carRepository)
	{this.carRepository=carRepository;}
	
	@Override
	@Transactional
	public Car save(Car car) throws Exception {
		return carRepository.save(car);
	}
	@Override
	@Transactional
	public void delete(Integer id) throws Exception {
		carRepository.deleteById(id);
	}
	
	@Override
	public List<Car> getAll() throws Exception {
		return carRepository.findAll();
	}
	
	@Override
	public Optional<Car> getById(Integer id) throws Exception {
		return carRepository.findById(id);
	}
	
	@Override
	public Car findByTuition(String tuition)  throws Exception {
		return carRepository.findByTuition(tuition);
	}
}
